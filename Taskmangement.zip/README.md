
# Task Management System

A full-stack task management application built with **MongoDB**, **Express.js**, **React.js**, and **Node.js** (MERN stack).

## Features

- User registration and login with JWT authentication
- Create, assign, and view tasks
- Separate views for creators and assignees
- RESTful API with protected routes
- React frontend with routing and authentication
- MongoDB for storing users and tasks

## Technologies Used

- **Frontend**: React.js, Axios, React Router
- **Backend**: Node.js, Express.js
- **Database**: MongoDB (via Mongoose)
- **Authentication**: JSON Web Tokens (JWT)

## Setup Instructions

### Backend (Server)

1. Navigate to the server folder:
    ```bash
    cd server
    ```

2. Install dependencies:
    ```bash
    npm install
    ```

3. Create a `.env` file:
    ```
    MONGO_URI=your_mongo_connection_string
    JWT_SECRET=your_jwt_secret
    ```

4. Start the server:
    ```bash
    node server.js
    ```

### Frontend (Client)

1. Navigate to the client folder:
    ```bash
    cd client
    ```

2. Install dependencies:
    ```bash
    npm install
    ```

3. Start the frontend:
    ```bash
    npm start
    ```

## Folder Structure

```
TaskManagementSystem/
├── client/         # React frontend
├── server/         # Express backend
├── README.md
```

## Author

Saswatika Sahu

## AI Usage (Optional)

The backend structure allows for AI integration such as:
- Task prioritization suggestions
- Notification generation using OpenAI
(Currently a placeholder for future implementation)

## License

This project is for academic/learning purposes.
